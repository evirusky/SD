# against_all
Repositorio privado con plantilla de despliegue y modulos funcionales para implementar el juego Against All